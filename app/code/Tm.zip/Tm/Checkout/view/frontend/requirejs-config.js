
var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Tm_Checkout/js/shipping-save-processor"
        }
    }
};

