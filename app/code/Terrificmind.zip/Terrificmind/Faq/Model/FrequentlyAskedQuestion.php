<?php
namespace Terrificmind\Faq\Model;
class FrequentlyAskedQuestion extends \Magento\Framework\Model\AbstractModel
{
	protected function _construct()
	{
		$this->_init('Terrificmind\Faq\Model\ResourceModel\FrequentlyAskedQuestion');
	}
}
